#pragma once

#include <vector>

namespace hyrise {

void micro_benchmark_clear_cache();

}  // namespace hyrise
