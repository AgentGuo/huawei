SELECT column_a FROM test_table;

