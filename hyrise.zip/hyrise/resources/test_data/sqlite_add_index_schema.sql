create table table_1
(
  column_1      integer      not null,
  column_2      varchar(16)          ,
  primary key (column_1)
);
