create index index_1 on table_1(column_1);
